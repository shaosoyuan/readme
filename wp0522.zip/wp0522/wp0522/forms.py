""" 表单提交规则 """
# -*- coding: utf-8 -*-
from django import forms

class LoginForm(forms.Form):
    """ 登录 """
    username = forms.CharField(max_length=100)
    password = forms.CharField(widget=forms.PasswordInput)
