from django.apps import AppConfig


class wp0522Config(AppConfig):
    name = 'wp0522'
