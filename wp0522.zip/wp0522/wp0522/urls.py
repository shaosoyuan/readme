from django.urls import path
from . import views
app_name = 'wp0522'
urlpatterns = [
    path('login/',views.login,name = 'login'),
    path('login_check/',views.login_check,name = 'login_check'),
    path('index/',views.index,name='index'),
    path('list_containers/',views.list_containers,name='list_containers'),
    path('add_containers/',views.add_containers,name='add_containers'),
    path('delete_containers/',views.delete_container,name='delete_containers'),
    path('detail_container/<containername>/',views.detail_container,name='detail_container'),
    path('object_list/',views.object_list,name="object_list"),
    path('object_content/',views.object_content,name="object_content"),
    path('object_upload/',views.object_upload,name="object_upload"),
    path('object_download/<object_name>',views.object_download,name="object_download"),
    path('object_delete/',views.delete_object,name="object_delete"),
    path('register/', views.register, name='register'),
    path('registers/', views.registers, name='registers'),
]